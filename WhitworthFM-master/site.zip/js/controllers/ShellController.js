whitworthFM.controller('ShellController',
    function ShellController($scope, $timeout, $interval, $http, $location) {

        $scope.currentPage = 'home';
        $scope.currentSong = {};
        $scope.songString = '';

        $scope.$on('$locationChangeSuccess', function() {
            $scope.currentPage = $location.path();
        });

        $scope.checkStatus = function() {
            if ($('#songTitle') && ($('#songTitle').html() != $scope.songString)) {
                $scope.songString = $('#songTitle').html();
                $scope.getSongDetails($scope.songString);
            }

            if (!$('#songTitle').html()) {
                $scope.currentSong.title = 'Not Currently Streaming'
            }
        }

        $scope.getSongDetails = function(val) {
            var splitString = val.split('-');
            $http({method: 'GET', url: 'https://api.spotify.com/v1/search?q=' + encodeURI(val) + '&type=track' }).
                success(function(data, status, headers, config) {
                    console.log(data);
                    if (data.tracks.items[0]) {
                        $scope.currentSong = data.tracks.items[0];
                    }

                    $scope.currentSong.title = splitString[1];
                    $scope.currentSong.artist = splitString[0]
                }).
                error(function(data, status, headers, config) {
                    console.log(data);
                });
        }


        $interval(function() {
            $scope.checkStatus();
            console.log('Checking');
        }, 1000);
    }
);
