whitworthFM.controller('HomeController',
    function HomeController($scope, $timeout, $interval, $http) {
        $timeout(function(){
            // Calling autoSize() from default.js
            autoSize();
            $scope.checkStatus();
        });

        $scope.showHint = function() {
            $scope.hint = true;

            $timeout(function() {
                $scope.hint = false;
            }, 5000);
        }
    }
);
